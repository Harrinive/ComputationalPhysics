# Computational Physics

## Assignment Week 1

last update: 03-03-2020

### Individual Assignment

1. Please install `JupyterLab` and submit a `JupyterNotebook` script.  
2. Please read [Project Report Guide](http://www.math.buffalo.edu/~badzioch/MTH337/report_guide.html) and complete your note-taking. You can take the Cornell note-taking system,  mind-mapping, 九宫格笔记法， 幕布 or other note-taking method. If you prefer handwriting, please take a picture of your writing and export/include the picture into a PDF file[^1].

[^1]: You can try `Office Lens` to export picture to pdf file.
