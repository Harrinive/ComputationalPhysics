# the first python scripting example

print("Hello World!") 

"""
Author: W.H. Gu
Date: 03.03.2020
Editor: VS Code
Python3.7.4: Anaconda Python
"""